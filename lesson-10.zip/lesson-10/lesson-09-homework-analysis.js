//
// Домашня робота:
// AK

Core.Print('\nLesson 09 - Homework');

// Будемо продовжувати роботу над студентом:

var student = {
	name: 'Petro',
	surname: 'Tymoshenko',
	email: 'p@igov.org.ua',
	address: 'Kyiv',
	birthdayDate: new Date(1986, 8, 24),
	getDaysToBirthday: function() {
		// TODO: look for best syntax
	},
	getInfo: function() {
		return this.name + ' ' + this.surname + ' ' + this.adress + ' ' + this.birthdayDate.toDateString();
	}
};

Core.Print('\nTask 9.1');
// (1 бал) 
// Прочитай уважно файл уроку. Використай метод Array.forEach для того, 
// щоб додати до кожного елементу масиву [21, 63, 84] число '42'
// TODO: пиши свій код тут:

var one = [21, 63, 84];
one.forEach(function(value, index, array) {
	// Core.Print(value+42);
	array[index] = value + 42;
});

Core.Print('\nTask 9.2');
// (2 бали) 
// Даний масив crazyMix, до якого увійшли елементи різних типів:
var crazyMix = [1, '1', true, 2, '02', 3, '0', '10', 11, [], {}, function() {}];

// Використай метод Array.filter у функції arrayCleanUp так,
// щоб вона повертала масив, до якого входять тільки числа з вхідного масиву 'arrayToCleanUp':

function arrayCleanUp(arrayToCleanUp) {
	var cleanedUp = arrayToCleanUp.filter(function(value) {
		return typeof value === 'number';
	});
	return cleanedUp;
}

var cleanedUp = arrayCleanUp(crazyMix).every(function(element) {
	return typeof element === 'number';
});

// TEST
if (cleanedUp) {
	Core.Print('Task 9.2 is DONE! ');
} else {
	Core.Print('Please make Task 9.2');
}

Core.Print('\nTask 9.3');
// (3 бали)
// Даний код. Допиши у ньому функцію findMaxInMatrix, 
// яка знаходить максимальний елемент матриці.

var matrix = [
	[21, 3, 4, 5],
	[4, 5, 29, 3],
	[2, 12, 4, 7]
];

function findMaxInMatrix(mtx) {
	// TODO: пишіть свій код тут:
	var currentMatrixElement;
	var l1 = mtx.length;
	var l2;
	var maxValue = 0;
	// counting arrays - elements of mtx
	for (var i = 0; i < l1; i++) {
		l2 = mtx[i].length;
		// counting elements of arrays which are elements of mtx array
		for (var j = 0; j < l2; j++) {
			currentMatrixElement = mtx[i][j];
			if (maxValue <= currentMatrixElement) {
				maxValue = currentMatrixElement;
			}
		}
	}
	return currentMatrixElement;
}

var res = findMaxInMatrix(matrix);

if (res === 29) {
	Core.Print('Task 9.3 is Done: ' + res);
} else {
	Core.Print('Please make Task 9.3');
}

Core.Print('\nLesson 09 - Homework End');



//
// Домашня робота:
// AG

Core.Print('\nLesson 09 - Homework');

// Будемо продовжувати роботу над студентом:

var student = {
	name: 'Petro',
	surname: 'Tymoshenko',
	email: 'p@igov.org.ua',
	address: 'Kyiv',
	birthdayDate: new Date(1986, 8, 24),
	getDaysToBirthday: function() {
		// TODO: look for best syntax
	},
	getInfo: function() {
		return this.name + ' ' + this.surname + ' ' + this.adress + ' ' + this.birthdayDate.toDateString();
	}
};

Core.Print('\nTask 9.1\n');
// (1 бал) 
// Прочитай уважно файл уроку. Використай метод Array.forEach для того, 
// щоб додати до кожного елементу масиву [21, 63, 84] число '42'
// TODO: пиши свій код тут:
var myArr = [21, 63, 84];
myArr.forEach(function(m, j, b) {
	var myResult = m + 42;
	Core.Print(myResult);
})


Core.Print('\nTask 9.2\n');
// (2 бали) 
// Даний масив crazyMix, до якого увійшли елементи різних типів:
var crazyMix = [1, '1', true, 2, '02', 3, '0', '10', 11, [], {}, function() {}];

// Використай метод Array.filter у функції arrayCleanUp так,
// щоб вона повертала масив, до якого входять тільки числа з вхідного масиву 'arrayToCleanUp':

function arrayCleanUp(arrayToCleanUp) {
	var cleanedUp = arrayToCleanUp;
	// TODO: пишіть свій код тут:
	return cleanedUp.filter(function(d) {
		typeof d != "function isNaN() { [native code] }";
	});
}

var cleanedUp = arrayCleanUp(crazyMix).every(function(element) {
	return typeof element === 'number';
});

if (cleanedUp) {
	Core.Print('Task 9.2 is DONE! ');
} else {
	Core.Print('Please make Task 9.2');
}

Core.Print('\nTask 9.3\n');
// (3 бали)
// Даний код. Допиши у ньому функцію findMaxInMatrix, 
// яка знаходить максимальний елемент матриці.

var matrix = [
	[21, 3, 4, 5],
	[4, 5, 29, 3],
	[2, 12, 4, 7]
];

function findMaxInMatrix(mtx) {
	//TODO: пишіть свій код тут:
	var m = 0;
	m = mtx.reduce(function(m1, n1) {
		return (m1 > n1) ? m1 : n1; //=> 4, 25, 29, 3
	});
	m = m.reduce(function(m2, n2) {
		return (m2 > n2) ? m2 : n2;
	});
	return m;

	// var newMtx;
	// for (var m = 0; m <= mtx.length; m++){
	// 	for (var n = 0; n <= mtx.length; n++){
	// 		if (mtx[m, n] > mtx[m+1, n+1]){
	// 			newMtx = mtx [m, n]
	// 		}
	//	 
	// 	}
	// }
	// return newMtx;
}
//FIXME:
//I don't undestand as search max element in array

p(findMaxInMatrix(matrix));

var res = findMaxInMatrix(matrix);

if (res === 29) {
	Core.Print('Task 9.3 is Done: ' + res);
} else {
	Core.Print('Please make Task 9.3');
}

Core.Print('\nLesson 09 - Homework End');



//
// Домашня робота:
// TM
//Core.Load('../../HomeWork/09/l-09.js')
Core.Print('\nLesson 09 - Homework');

Core.Print('\nTask 9.1\n');
// (1 бал) 
// Прочитай уважно файл уроку. Використай метод Array.forEach для того, 
// щоб додати до кожного елементу масиву [21, 63, 84] число '42'
// TODO: пиши свій код тут:
var testArray = [21, 63, 84];
var addNum = 42;
testArray.forEach(function(element, index, array) {
	array[index] = element + addNum;
})
Core.Print(testArray);

Core.Print('\nTask 9.2');
// (2 бали) 
// Даний масив crazyMix, до якого увійшли елементи різних типів:
var crazyMix = [1, '1', true, 2, '02', 3, '0', '10', 11, [], {}, function() {}];

// Використай метод Array.filter у функції arrayCleanUp так,
// щоб вона повертала масив, до якого входять тільки числа з вхідного масиву 'arrayToCleanUp':

function arrayCleanUp(arrayToCleanUp) {
	var cleanedUp = arrayToCleanUp;

	function filtering(value) {
		// Стисла версія:
		// return typeof(value) === 'number';
		if (typeof(value) === 'number') {
			return true;
		} else {
			return false;
		}
	}
	cleanedUp = crazyMix.filter(filtering);
	Core.Print(cleanedUp);
	return cleanedUp;
}


//Verification if new Array has all elements numbers. true/false
var cleanedUp = arrayCleanUp(crazyMix).every(function(element) {
	return typeof element === 'number';
});

if (cleanedUp) {
	Core.Print('Task 9.2 is DONE! ');
} else {
	Core.Print('Please make Task 9.2');
}


Core.Print('\nTask 9.3');
// (3 бали)
// Даний код. Допиши у ньому функцію findMaxInMatrix, 
// яка знаходить максимальний елемент матриці.

var matrix = [
	[21, 3, 4, 5],
	[4, 5, 29, 3],
	[2, 12, 4, 7]
];

function findMaxInMatrix(mtx) {
	// TODO: пишіть свій код тут:
	var max = 0;
	for (var i = 0; i < mtx.length; i++) {
		for (var k = 0; k < mtx[i].length; k++) {
			if (max < mtx[i][k]) {
				max = mtx[i][k];
			}
		}
	};
	return max;
};

var res = findMaxInMatrix(matrix);

if (res === 29) {
	Core.Print('Task 9.3 is Done: ' + res);
} else {
	Core.Print('Please make Task 9.3');
}

Core.Print('\nLesson 09 - Homework End');



//
// Домашня робота:
// OM

Core.Print('\nLesson 09 - Homework');

// Будемо продовжувати роботу над студентом:

var student = {
	name: 'Petro',
	surname: 'Tymoshenko',
	email: 'p@igov.org.ua',
	address: 'Kyiv',
	birthdayDate: new Date(1986, 8, 24),
	getDaysToBirthday: function() {
		// TODO: look for best syntax
		var birthday = new Date(1986, 8, 24);
		var today = new Date();
		birthday.setFullYear(today.getFullYear());
		if (today > birthday) {
			birthday.setFullYear(today.getFullYear() + 1);
		}
		var daysToBD = Math.floor((birthday - today) / (1000 * 60 * 60 * 24));
	},
	getInfo: function() {
		return this.name + ' ' + this.surname + ' ' + this.adress + ' ' + this.birthdayDate.toDateString();
	}
};
Core.Print('\nTask 9.1');
// (1 бал) 
// Прочитай уважно файл уроку. Використай метод Array.forEach для того, 
// щоб додати до кожного елементу масиву [21, 63, 84] число '42'
// TODO: пиши свій код тут:

// FIXME: I've been trying to figure out how instead of index of array put to
// output the value of this index, to get the result like this:
// 			Summ of 21 + 42 = 63
// 			Summ of 63 + 42 = 105
// 			Summ of 84 + 42 = 126
// But I don't realized it yet. Could you give me a hint...?
var myArr = [21, 63, 84];
myArr.forEach(function(value, index, array) {
	value += 42;
	p('Summ of array index[' + index + '] + 42 = ' + value);
});


Core.Print('\nTask 9.2');
// (2 бали) 
// Даний масив crazyMix, до якого увійшли елементи різних типів:
var crazyMix = [1, '1', true, 2, '02', 3, '0', '10', 11, [], {}, function() {}];

// Використай метод Array.filter у функції arrayCleanUp так,
// щоб вона повертала масив, до якого входять тільки числа з вхідного масиву 'arrayToCleanUp':

function arrayCleanUp(arrayToCleanUp) {
	var cleanedUp = arrayToCleanUp.filter(function(num) {
		return typeof num === 'number';
	});

	return cleanedUp;
}

var cleanedUp = arrayCleanUp(crazyMix).every(function(element) {
	return typeof element === 'number';
});

if (cleanedUp) {
	Core.Print('Task 9.2 is DONE! ');
} else {
	Core.Print('Please make Task 9.2');
}
Core.Print('\nTask 9.3');
// (3 бали)
// Даний код. Допиши у ньому функцію findMaxInMatrix, 
// яка знаходить максимальний елемент матриці.

var matrix = [
	[21, 3, 4, 5],
	[4, 5, 29, 3],
	[2, 12, 4, 7]
];

function findMaxInMatrix(mtx) {
	// TODO: пишіть свій код тут:
	var arrOfMax = mtx.map(function(x) {
		return x.reduce(function(a, b) {
			return (a > b) ? a : b;
		});
	});
	var theMaxOfTheMax = arrOfMax.reduce(function(a, b) {
		return (a > b) ? a : b;
	});
	return theMaxOfTheMax;
}

var res = findMaxInMatrix(matrix);

if (res === 29) {
	Core.Print('Task 9.3 is Done: ' + res);
} else {
	Core.Print('Please make Task 9.3');
}

// FIXME:
// This function works only with "matrix" as is
// If we have an array with numbers only
// var matrix = [ 21, 3, 4, 5, 4, 5, 29, 3, 2, 12, 4, 7];
// the function should be like this:

/*function findMaxInMatrix(mtx) {
 var theMaxOfTheMax = mtx.reduce(function(a, b) {
   return ( a > b ) ? a : b;
  });
 return theMaxOfTheMax;
}

var res = findMaxInMatrix(matrix);

if (res === 29) {
 Core.Print('Task 9.3 is Done: ' + res);
} else {
 Core.Print('Please make Task 9.3');
}*/

// But what if we have an array with both nums and arrays inside...?
// var matrix = [21, 3, 4, 5 ,[ 4, 5, 29, 3 ], 2, 12, 4, 7 ];
//
// I think some universal function will be the propper resolve in this case...
// Trying to resolve this task, using filter with "if", "else" and "typeof"
// Will let you know the result as soon as it'll be done...
Core.Print('\nLesson 09 - Homework End');